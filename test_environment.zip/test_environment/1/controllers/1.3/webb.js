'use strict';

exports = module.exports = function (req, res, cb) {
	res.data	= '{"v": "1.3.2"}';
	cb();
};
