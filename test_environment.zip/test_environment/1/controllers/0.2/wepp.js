'use strict';

exports = module.exports = function (req, res, cb) {
	res.data	= {'v': '0.2.0'};
	cb();
};
